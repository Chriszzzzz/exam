from __future__ import unicode_literals

from django.apps import AppConfig


class ExamProjectConfig(AppConfig):
    name = 'exam_project'
